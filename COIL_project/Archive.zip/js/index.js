//Array 1 - Cards + Animate on click flip


//Array 2 - Limitations

